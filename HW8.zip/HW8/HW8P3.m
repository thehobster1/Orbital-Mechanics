re = 6378.100;
PeriapsisRadiusEarth = 195 + re;
EccentricityEarth = 0;

rj = 69911;
PeriapsisRadiusJupiter = 3 * rj;
EccentricityJupiter = 0;

earthOrbit = [PeriapsisRadiusEarth EccentricityEarth];
jupiterOrbit = [PeriapsisRadiusJupiter EccentricityJupiter];

[deltaV, TOF] = orbitalTransferGravityFields(earthOrbit, jupiterOrbit);
