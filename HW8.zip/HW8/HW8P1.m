Re = 6378100;

initial_radius = 1.1*Re; % Initial orbit radius in meters
final_radius = 20*Re; % Final orbit radius in meters
intermediate_radius = 62*Re; % Intermediate orbit radius in meters

me = 5.97*10^24; % Gravitational parameter of Earth in m^3/s^2

[time_of_flight, delta_V_total] = hohmann_transfer(initial_radius, final_radius, me);
[time_of_flight_Bi, delta_V_total_Bi, v_transfer1_2] = bi_elliptical_transfer(initial_radius, intermediate_radius, final_radius, me);

fprintf('Hohmann Transfer\n');
fprintf('Time of Flight: %.2f seconds\n', time_of_flight);
fprintf('Total Delta V: %.2f m/s\n', delta_V_total);

fprintf('\n');
fprintf('Bi-Elliptical\n');

fprintf('Time of Flight: %.2f seconds\n', time_of_flight_Bi);
fprintf('Total Delta V: %.2f m/s\n', delta_V_total_Bi);