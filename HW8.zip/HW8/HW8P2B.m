Re = 6378100;

initial_radius = 195000 + Re; % Initial orbit radius in meters
final_radius = initial_radius; % Final orbit radius in meters
intermediate_radius = 50*Re; % Intermediate orbit radius in meters
i = 80;
me = 5.97*10^24; % Gravitational parameter of Earth in m^3/s^2

[time_of_flight_Bi, delta_V_total_Bi, v_transfer1_2] = bi_elliptical_transfer(initial_radius, intermediate_radius, final_radius, me);
fprintf('Bi-Elliptical\n');

fprintf('Time of Flight: %.2f seconds\n', time_of_flight_Bi);
deltaVManeuver = sqrt(2)*v_transfer1_2*sqrt(1-cosd(i));
fprintf('Delta V Transfer: %.2f m/s\n', delta_V_total_Bi);
fprintf('Delta V Maneuver: %.2f m/s\n', deltaVManeuver);
fprintf('Total Delta V: %.2f m/s\n', delta_V_total_Bi + deltaVManeuver);


