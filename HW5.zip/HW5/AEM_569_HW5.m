clear
clc
close

re = 6378140;

me = 5.97219e24; %kg
G = 6.6743e-11;

r1 = [2.12*re; 2.73*re; -0.6*re]; %m

v1 = [-3.4; 1.62; 2.9]*1000; %m/s

%r1 = [1.6772*re; -1.6772*re; 2.3719*re]; %m
%v1 = [3.1574; 2.4987; 0.4658]*1000; %m/s

orbital_params = calculate_orbital_parameters(r1, v1, me);
disp(orbital_params);

tdel = 7*60*60;

t2 = tdel + orbital_params.tmintp;


orbital_params2 = calculateOrbitTimePassParam(me, orbital_params.SemiMajorAxis, orbital_params.Eccentricity, t2, r1, v1, orbital_params.r_m, orbital_params.Theta);
disp(orbital_params2);

delTheta = 360 + orbital_params2.Theta - orbital_params.Theta;
delE = orbital_params2.E2 - orbital_params.E;

%Changing Vectors
a = orbital_params.SemiMajorAxis;
e = orbital_params.Eccentricity;
E = orbital_params.E;
mu = me*G;
n = sqrt(mu/a^3);
b = sqrt(a^2*(1 - e^2));
omega = orbital_params.RAAN;
i = orbital_params.Inclination;
theta = orbital_params.Theta;

%e and p vector
r1ep = [a*(cosd(E) - e); b*sind(E)];
disp(r1ep);
v1ep = [-a^2*n/orbital_params.r_m*sind(E); a*b*n/orbital_params.r_m*cosd(E)];
disp(v1ep);

%r and theta vector
pol = [(cosd(omega)*cosd(theta) - sind(omega)*cosd(i)*sind(theta))*r1(1) + (sind(omega)*cosd(theta) - cosd(omega)*cosd(i)*sind(theta))*r1(2) + sind(i)*sind(theta)*r1(3);...
    (-cosd(omega)*sind(theta) - sind(omega)*cosd(i)*cosd(theta))*r1(1) + (-sind(omega)*sind(theta) - cosd(omega)*cosd(i)*cosd(theta))*r1(2) - cosd(i)*sind(theta)*r1(3);...
    sind(omega)*sind(i)*r1(1) - cosd(omega)*sind(i)*r1(2) + cosd(i)*r1(3)];

rp = a*(1-e);
figure(1)
axis equal
hold on
grid on
plot(a,0,'o')
plot(a - rp, 0, 'o')

x0 = 0;
y0 = 0;
t = -pi:0.01:pi;
x = x0 + a*cos(t);
y = y0 + b*sin(t);
plot(x,y)

x = re*cos(t) + a - rp;
y = re*sin(t);
plot(x,y)

plot(r1ep(1) + a*e, r1ep(2), 'o');
plot(orbital_params2.r2VecP(1) + a*e,orbital_params2.r2VecP(2), 'o');

period = 2*pi()*sqrt(a^3/mu);
t2 = t2/60/60;

a = 2.5*re;
e = 0.4;
rp = a*(1-e);
b = sqrt(a^2*(1 - e^2));
figure(2)
axis equal
hold on
grid on
plot(a,0,'o')
plot(a - rp, 0, 'o')

x0 = 0;
y0 = 0;
t = -pi:0.01:pi;
x = x0 + a*cos(t);
y = y0 + b*sin(t);
plot (x,y);
