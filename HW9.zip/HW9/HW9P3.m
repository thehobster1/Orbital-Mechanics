clear all
close all

AU = 150000000;
Rx = 4000000;
r1 = AU;
r2 = 3.2*AU;

mu = 5*10^4*(1000)^3;
G = 6.6743*10^-11;
m = mu/G;
eta = 135;

%[time_of_flight, delta_V_total, phi, S] = hohmann_transfer(r1, r2, m);

[a, p, e, TOF, rd, vd, gammad, thetaStard, ra, va, gammaa, thetaStara, delVd, alphad, delVa, alphaa, viVec, vfVec, vdVec, vaVec] = lambertArcs(r1, r2, m, eta)

figure(1);
hold on
grid on
axis equal

plot (0, 0, "ob")

x0 = 0;
y0 = 0;
t0 = -pi:0.01:pi;
x1 = x0 + r1*cos(t0);
y1 = y0 + r1*sin(t0);
plot (x1,y1, "k");
plot (0, -r1, "ok")

x2 = x0 + r2*cos(t0);
y2 = y0 + r2*sin(t0);
plot (x2,y2, "m");
plot (r2*sind(eta), -r2*cosd(eta), "om")

x = p./(1+e*cos(t0));

[xCoord, yCoord] = pol2cart(t0 + deg2rad(eta - 90 - thetaStara), x);
plot(xCoord, yCoord, "r");

xlabel('x (m)');
ylabel('y (m)');
hold off