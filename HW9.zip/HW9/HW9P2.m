close all
clear all

Re = 6378100;
m = 5.97*10^24;
r1 = Re*[3 1 0];
r2 = Re*[-1 2*sqrt(3) 2];
G = 6.67*10^-11;

eta = acosd(dot(r1,r2)/(norm(r1)*norm(r2)));

h = cross(r1,r2)/norm(cross(r1,r2));

[i, RAAN] = transferPlane(r1, r2);
[a, p, e, TOF, rd, vd, gammad, thetaStard, ra, va, gammaa, thetaStara, delVd, alphad, delVa, alphaa, viVec, vfVec, vdVec, vaVec] = lambertArcs(norm(r1), norm(r2), m, eta);

energy = -m*G/(2*a);

theta2 = asind(r2(3)/sind(i)/norm(r2));

omega = theta2 + thetaStara;

theta = mod(thetaStard + omega, 360);

vdVec = vd*[(cosd(RAAN)*cosd(theta)-sind(RAAN)*cosd(i)*sind(theta))*-sind(gammad)-(cosd(RAAN)*sind(theta)+sind(RAAN)*cosd(i)*cosd(theta))*cosd(gammad) (sind(RAAN)*cosd(theta)+cosd(RAAN)*cosd(i)*sind(theta))*-sind(gammad)-(sind(RAAN)*sind(theta)-cosd(RAAN)*cosd(i)*cosd(theta))*cosd(gammad) sind(i)*sind(theta)*sind(gammad)+sind(i)*cosd(theta)*cosd(gammad)];
v1 = sqrt(m*G/norm(r1));
v1Vec = v1*cross([0 0 1], r1/norm(r1));


delVdVec = vdVec - v1Vec;

orbital_parameters = calculate_orbital_parameters(r1, vdVec, m);

t = 0;

orbitTimePass = calculateOrbitTimePassParam (m, a, e, t, r1, vdVec, norm(r2), thetaStara - thetaStard);