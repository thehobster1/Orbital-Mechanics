close all
clear all

g = 6.6743*10^-11;

re = 6378.1;
me = 5.94*10^24;
mu = g*me/1000^3;

transAng = 240;
time = 8*3600;


%r1 = [2*re; 0; 0];
%r2 = 6.6*re*[cosd(transAng); sind(transAng); 0];

ai = 1.5*re;
ei = 0;
ii = 0;
RAANi = 0;
peri = 0;
thetai = 0;

af = 8*re;
ef = 0.2;
iF = 30;
RAANf = 45;
perf = 60;
thetaf = 240;

hi = sqrt(mu*ai*(1-ei^2));
hf = sqrt(mu*af*(1-ef^2));


[ri , vi] = rv_from_coe(hi, ei, ii, RAANi, peri, thetai, mu);
[rf , vf] = rv_from_coe(hf, ef, iF, RAANf, perf, thetaf, mu);

[V1, V2] = lambert2(ri, rf, time, 1e-6, mu);

r1 = norm(ri);
r2 = norm(rf);
v1 = norm(V1);
v2 = norm(V2);

[h, e, i, omega, w, theta] = coe_from_rv(ri,V1,mu);

[h2, e2, i2, omega2, w2, theta2] = coe_from_rv(rf,V2,mu);

%vi = sqrt(mu/norm(ri))*[0; 1; 0];

%vf = sqrt(mu/norm(ri))*[-sind(transAng); cosd(transAng); 0];

dV1 = (V1 - vi);

dV2 = (vf - V2);

dv1 = norm(V1 - vi);

dv2 = norm(vf - V2);

dVTotal = dv1 + dv2;

%kepler = kepler_convert(ri,v1,mu);
%kepler2 = kepler_convert(rf,v2,mu);

gamma = flightPathAngle (ri, V1, e, theta);
gamma2 = flightPathAngle (rf, V2, e2, theta2);

alpha = burnAngle (dV1, vi);
alpha2 = burnAngle (dV2, V2);

p = h^2/mu;

a = p/(1-e^2);