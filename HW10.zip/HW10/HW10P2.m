close all
clear all

g = 6.6743*10^-11;

re = 6378.1;
me = 5.94*10^24;
mu = g*me/1000^3;

transAng = 240;
time = 8*3600;


%r1 = [2*re; 0; 0];
%r2 = 6.6*re*[cosd(transAng); sind(transAng); 0];

ai = 1.5*re;
ei = 0;
ii = 0;
RAANi = 0;
peri = 0;
thetai = 0;

af = 8*re;
ef = 0.2;
iF = 30;
RAANf = 45;
perf = 60;
thetaf = 240;

hi = sqrt(mu*ai*(1-ei^2));
hf = sqrt(mu*af*(1-ef^2));


[ri , vi] = rv_from_coe(hi, ei, ii, RAANi, peri, thetai, mu);
[rf , vf] = rv_from_coe(hf, ef, iF, RAANf, perf, thetaf, mu);

[v1, v2] = lambert2(ri, rf, time, 1e-10, mu);

[h, e, i, omega, w, theta] = coe_from_rv(ri,v1,mu);

[h2, e2, i2, omega2, w2, theta2] = coe_from_rv(rf,v2,mu);

%vi = sqrt(mu/norm(ri))*[0; 1; 0];

%vf = sqrt(mu/norm(ri))*[-sind(transAng); cosd(transAng); 0];

dV1 = (v1 - vi);

dV2 = (vf - v2);

dv1 = norm(v1 - vi);

dv2 = norm(vf - v2);

dVTotal = dv1 + dv2;

%kepler = kepler_convert(ri,v1,mu);
%kepler2 = kepler_convert(rf,v2,mu);

gamma = flightPathAngle (ri, v1, e, theta);
gamma2 = flightPathAngle (rf, v2, e2, theta2);

alpha = burnAngle (dV1, vi);
alpha2 = burnAngle (dV2, v2);