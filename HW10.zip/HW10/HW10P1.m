close all
clear all

g = 6.6743*10^-11;

re = 6378.1;
me = 5.94*10^24;
mu = g*me/1000^3;

transAng = 235;
time = 8*3600;


R1 = [2*re 0 0];
R2 = 6.6*re*[cosd(transAng) sind(transAng) 0];

r1 = norm(R1);
r2 = norm(R2);

[V1, V2] = lambert2(R1, R2, time, 1e-10, mu);

[h, e, i, omega, w, theta] = coe_from_rv(R1,V1,mu);

[h2, e2, i2, omega2, w2, theta2] = coe_from_rv(R2,V2,mu);

vi = sqrt(mu/norm(R1))*[0 1 0];

vf = sqrt(mu/norm(R2))*[-sind(transAng) cosd(transAng) 0];

dV1 = (V1 - vi);

dV2 = (vf - V2);

dv1 = norm(V1 - vi);

dv2 = norm(vf - V2);

v1 = norm(V1);
v2 = norm(V2);

dVTotal = dv1 + dv2;

%kepler = kepler_convert(r1,v1,mu);
%kepler2 = kepler_convert(r2,v2,mu);

gamma = flightPathAngle (R1, V1, e, theta);
gamma2 = flightPathAngle (R2, V2, e2, theta2);

%[r , v] = rv_from_coe(h, e, 0, 0, 0, theta, mu);

alpha = burnAngle (dV1, vi);
alpha2 = burnAngle (dV2, V2);

figure(1)
figure(1);
hold on
grid on
axis equal

plot (0, 0, "ok");
plot (R1(1), R1(2), 'ok');
plot (R2(1), R2(2), 'ok');
plot2DOrbit (norm(R1), 0, 0, 2*pi(), 0, 'r');
plot2DOrbit (norm(R2), 0, 0, 2*pi(), 0, 'b');
a = h^2/(mu*(1-e^2));
plot2DOrbit (a, e, deg2rad(theta-360), deg2rad(theta2), theta, 'm');
plot(-a*cosd(theta), a*sind(theta), 'ok');

xlabel('x (m)');
ylabel('y (m)');
hold off

phase = transAng - rad2deg(time*sqrt(mu/norm(R2)^3));