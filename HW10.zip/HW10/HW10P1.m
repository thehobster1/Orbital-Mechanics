close all
clear all

g = 6.6743*10^-11;

re = 6378.1;
me = 5.94*10^24;
mu = g*me/1000^3;

transAng = 235;
time = 8*3600;


r1 = [2*re 0 0];
r2 = 6.6*re*[cosd(transAng) sind(transAng) 0];

[v1, v2] = lambert(r1, r2, time, 1e-10, mu);

[h, e, i, omega, w, theta] = coe_from_rv(r1,v1,mu);

[h2, e2, i2, omega2, w2, theta2] = coe_from_rv(r2,v2,mu);

vi = sqrt(mu/norm(r1))*[0 1 0];

vf = sqrt(mu/norm(r2))*[-sind(transAng) cosd(transAng) 0];

dV1 = (v1 - vi);

dV2 = (vf - v2);

dv1 = norm(v1 - vi);

dv2 = norm(vf - v2);

dVTotal = dv1 + dv2;

%kepler = kepler_convert(r1,v1,mu);
%kepler2 = kepler_convert(r2,v2,mu);

gamma = flightPathAngle (r1, v1, e, theta);
gamma2 = flightPathAngle (r2, v2, e2, theta2);

%[r , v] = rv_from_coe(h, e, 0, 0, 0, theta, mu);

alpha = burnAngle (dV1, vi);
alpha2 = burnAngle (dV2, v2);

figure(1)
figure(1);
hold on
grid on
axis equal

plot (0, 0, "ok");
plot (r1(1), r1(2), 'ok');
plot (r2(1), r2(2), 'ok');
plot2DOrbit (norm(r1), 0, 0, 2*pi(), 0, 'r');
plot2DOrbit (norm(r2), 0, 0, 2*pi(), 0, 'b');
a = h^2/(mu*(1-e^2));
plot2DOrbit (a, e, deg2rad(theta-360), deg2rad(theta2), theta, 'm');

xlabel('x (m)');
ylabel('y (m)');
hold off

phase = transAng - rad2deg(time*sqrt(mu/norm(r2)^3));