clear
clc
close

re = 6378140;

me = 5.97219e24; %kg
G = 6.6743e-11;

a = 6.8*re;

e = 0.6;

r0 = [2.9*re; 5*re; 0*re]; %m

r0norm = norm(r0);

v0 = [-3.0; 2.0; 2.5]*1000; %m/s

v0norm = norm(v0);

orbital_params = calculate_orbital_parameters(r0, v0, me);
disp(orbital_params);

v0vec = norm(v0)*[sind(orbital_params.Gamma), cosd(orbital_params.theta)];

theta = pi();
deltaVa = ellipseToCircle(e, a, me, theta);
disp(deltaVa);


p = (a*(1-e^2));
rp = p/(1+e);

figure(1)
polarplot(0, 0, 'o')

hold on
polarplot(0,rp,'o')

thetaG = -pi():0.01:pi();
r = p*(1+e*cos(thetaG)).^-1;
polarplot(thetaG, r)

thetaTest = theta;

r1 = p/(1+e*cos(theta));

polarplot(theta, r1, 'o');


polarplot(thetaG, r1+zeros(size(thetaG)));
hold off;





disp(' ');
%Part B
theta = deg2rad(135);
deltaVb = ellipseToCircle(e, a, me, theta);
disp(deltaVb);

figure(2)
polarplot(0, 0, 'o')

hold on
polarplot(0,rp,'o')

r = p*(1+e*cos(thetaG)).^-1;
polarplot(thetaG, r)

thetaTest2 = theta;

r2 = p/(1+e*cos(theta));

polarplot(theta, r2, 'o');

polarplot(thetaG, r2+zeros(size(thetaG)));
hold off;