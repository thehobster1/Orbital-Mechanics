clear all
close all

me = 5.97*10^24;
G = 6.6743*10^-11;
mu = me*G;

re = 6378100;

a1 = 1.5*re;
e1 = 0;
i1 = 0;
RAAN1 = 0;
w1 = 0;
theta1 = 0;
h1 = sqrt(mu*a1*(1-e1^2));

a2 = 5.3*re;
e2 = 0.25;
i2 = 35;
RAAN2 = 45;
w2 = 60;
h2 = sqrt(mu*a2*(1-e2^2));

theta2 = 260 - w2;

dt = 10*3600;

tolerance = 10^-8;

[R1 , V1] = rv_from_coe(h1, e1, i1, RAAN1, w1, theta1, mu);

[R2 , V2] = rv_from_coe(h2, e2, i2, RAAN2, w2, theta2, mu);

[VD, VA] = lambert2(R1, R2, dt, tolerance, mu);

r1 = norm(R1);
r2 = norm(R2);

vd = norm(VD);
va = norm(VA);

[hD, eD, iD, omegaD, wD, thetaD] = coe_from_rv(R1,VD,mu);

[hA, eA, iA, omegaA, wA, thetaA] = coe_from_rv(R2,VA,mu);

a = hD^2/mu/(1-eD^2);

gamma = flightPathAngle (R1, VD, eD, thetaD);
gamma2 = flightPathAngle (R2, VA, eA, thetaA);

dV1 = (VD - V1);

dV2 = (V2 - VA);

dvT1 = norm(dV1) + norm(dV2);