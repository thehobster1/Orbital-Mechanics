function plot2DOrbit (a, e, t1, t2, theta, color)

    %t is in radians
    %omega is in degrees
    t0 = t1:0.01:t2;
    p = a*(1-e^2);
    x = p./(1+e*cos(t0));
    
    [xCoord, yCoord] = pol2cart(t0 - deg2rad(theta), x);
    plot(xCoord, yCoord, color);
end