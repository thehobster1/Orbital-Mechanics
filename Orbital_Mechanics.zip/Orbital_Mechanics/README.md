# Orbital_Mechanics

This is a repository of useful orbital dynamics programs. All equations are taken from <i>Orbital Mechanics for Engineering Students</i> by Howard D. Curtis

## Citations:

- rkf45.m, Howard D. Curtis, <i>Orbital Mechanics for Engineering Students</i>, Third Edition, 2010

- atmosphere.m, Howard D. Curtis, <i>Orbital Mechanics for Engineering Students</i>, Third Edition, 2010
