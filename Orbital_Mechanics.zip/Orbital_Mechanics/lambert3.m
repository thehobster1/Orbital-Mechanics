function [V1, V2] = lambert3(R1, R2, dt, tolerance, grav, dth)
    
    % function [v1, v2] = lambert(R1, R2, dt,guess, tolerance, grav)
    %
    % Purpose:  This function calculates the coe of an object using
    %           Lambert's problem to solve for the velocity.
    %
    % Inputs:   o R1        - The 1st position vector [km]
    %           o R2        - The position vector after time dt [km]
    %           o dt        - The time interval between R1 and R2 [s]
    %           o tolerance - The tolderance for the zero of z [OPTIONAL]
    %           o grav      - The standard grav param [km^3/s^2] [OPTIONAL]
    %
    % Outputs:  o v1        - The velocity vector at R1
    %           o v2        - The velocity vector at R2
    %
    % Required: coe_from_rv.m, stumpff.m
    %
    
    %% Constants
    if nargin == 3
        mu = 398600;
        tol = 1e-8;
    elseif nargin == 4
        mu = 398600;
        tol = tolerance;
    else
        mu = grav;
        tol = tolerance;
    end
    dth = dth*pi()/180;
    %% Calculate norm of r1 and r2
    r1 = norm(R1);
    r2 = norm(R2);
    %r1xr2 = cross(R1,R2);
    %{
    %% Choose either prograde or retrograde orbit
    orbit = input('Please choose either prograde or retrograde orbit\n', 's');
    orbit = lower(orbit);
    
    if strcmp(orbit, 'prograde') || strcmp(orbit,'pro')
        if r1xr2(3) > 0
            dth = acos( dot(R1,R2)/(r1*r2) );
        else
            dth = 2*pi - acos( dot(R1,R2)/(r1*r2) );
        end
    elseif strcmp(orbit, 'retrograde') || strcmp(orbit,'retro')
        if r1xr2(3) >= 0
            dth = 2*pi - acos( dot(R1,R2)/(r1*r2) );
        else
            dth = acos( dot(R1,R2)/(r1*r2) );
        end
    else
        error('Error: Please input "prograde" or "retrograde"')
    end
    %}

    c = sqrt(r1^2 + r2^2 -2*r1*r2*cos(dth));

    a0 = (r1 + r2 + c)/4;
    s = 2*a0;

    spaceTriangleAlpha0 = 2*asin(sqrt(s/(2*a0)));
    spaceTriangleBeta0 = 2*asin(sqrt((s - c)/(2*a0)));

    alpha = spaceTriangleAlpha0;
    beta = spaceTriangleBeta0;

    if dth <= 180
        TOFm = sqrt(a0^3/mu)*(spaceTriangleAlpha0 - spaceTriangleBeta0 - (sin(spaceTriangleAlpha0) - sin(spaceTriangleBeta0)));
    else
        TOFm = sqrt(a0^3/mu)*(2*pi() - (spaceTriangleAlpha0 - sin(spaceTriangleAlpha0)) + (spaceTriangleBeta0 - sin(spaceTriangleBeta0)));
    end
    
    a = a0;

    a2 = a;

    step = 1000000;

    TOF = TOFm;

    while abs(TOF - dt) > tol
        a = a2;
        alpha = 2*asin(sqrt(s/(2*a)));
        beta = 2*asin(sqrt((s - c)/(2*a)));
        if dth > pi()
            beta = -1*beta;
        end

        if dt > TOFm
            alpha = 2*pi() - alpha;
        end

        TOF = sqrt(a^3/mu)*(alpha - beta - (sin(alpha) - sin(beta)));
        
        if dt > TOFm
            if TOF < dt
                a2 = a + step;
            else
                a2 = a - step;
                step = step/2;
            end
        else
            if TOF > dt
                a2 = a + step;
            else
                a2 = a - step;
                step = step/2;
            end
        end
        
    end
    
    
    p1 = 4*a*(s-r1)*(s-r2)/c^2*sin((alpha - beta)/2); 
    p2 = 4*a*(s-r1)*(s-r2)/c^2*sin((alpha + beta)/2); 
    
    if TOFm < dt
        if p1 > p2
            p = p2;
        else
            p = p1;
        end
    else
        if p1 > p2
            p = p1;
        else
            p = p2;
        end
    end
        
    %% f and g functions
    f    = 1 - r2/p*(1-cos(dth));
    g    = r1*r2/sqrt(p*mu)*sin(dth);
    
    
    %% Calculate the velocity vector v1
    V1 = 1/g * (R2 - f*R1);

    fdot = dot(R1, V1)/(p*r1)*(1-cos(dth)) - 1/r1*sqrt(mu/p)*sin(dth);
    gdot = 1-r1/p*(1-cos(dth));
    
    %% calculate the velocity vector v2
    V2 = fdot*R1 + gdot*V1;

    TOF
end