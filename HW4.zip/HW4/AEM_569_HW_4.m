clear
clc
close

a = 8.948*10^6 %m
b = 8.613*10^6 %m
rp = 6.5225*10^6 %m
re = 6378100 %m
e = 0.27107;


figure(1)
axis equal
hold on
grid on
plot(a,0,'o')
plot(a - rp, 0, 'o')

x0 = 0;
y0 = 0;
t = -pi:0.01:pi
x = x0 + a*cos(t);
y = y0 + b*sin(t);
plot(x,y)

x = re*cos(t) + a - rp;
y = re*sin(t);
plot(x,y)

plot(a*e-7.567*10^6, -6.926*10^6, 'o')
line([a*e a*e-7.567*10^6], [0 -6.9264*10^6]) 

ve = 4738;
vp = -3274;
v = sqrt(ve^2 + vp^2);

length = 10^6;
line([a*e-7.567*10^6 a*e-7.567*10^6+length*ve/v], [-6.926*10^6 -6.926*10^6+length*vp/v])

%% Hyperbola
figure(2)
hold on
grid on
axis equal
a = -1.9896*10^6; %m
e = 4.5344;
b = a*sqrt(e^2-1);
rp = 7.032*10^6; %m
plot(0,0,'o')
plot(rp,0,'o')
%plot(rp - a,0,'o')
p = 38.9187*10^6;

yh=-5*10^7:100:5*10^7;
xh = -sqrt(a^2*(1 + (yh.^2)/(b^2))) + rp - a;
plot(xh,yh)


plot(6.9797*10^6, -2.0339*10^6, 'o')
line([0 6.9797*10^6], [0 -2.0339*10^6]) 
ve = 2842.8;
vp = 5008.7;
v = sqrt(ve^2 + vp^2);

line([0 rp-a], [0 0])
line([0 0], [0 p]) % p
line([rp-a -2.5*10^6], [0 (-2.5*10^6-(rp-a))*-1*b/a])

length = 3*10^6;
line([6.9797*10^6 6.9797*10^6+length*ve/v], [-2.0339*10^6 -2.0339*10^6+length*vp/v])