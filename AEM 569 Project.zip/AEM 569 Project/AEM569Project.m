close all;

clear all;

%Initial Conditions
Alt1 = 420000;

Alt2 = 35786000;

rE = 6378137; %m

r0 = Alt1 + rE; %m

r1 = Alt2 + rE; %m

IspH = 300;

mE = 5.97219*10^24; %kg

G = 6.6743*10^-11; %m^3/(kg*s^2)

v1 = sqrt(G*mE/r0); %m/s

v2 = sqrt(G*mE/r1); %m/s

m0 = 10; %kg

mu = G*mE; %m^3/s^2

Isp = 2300; %s

g0 = G*mE/(rE)^2;


%Hohmann Transfer
deltaVhohm = sqrt(mu/r0)*(sqrt(2*r1/(r0+r1))-1);

deltaThohm = pi()*sqrt((r0+r1)^3/(8*mu));

deltaThohmHr = deltaThohm/3600;

deltaThohmDay = deltaThohmHr/24;


%Ion Thruster
thrust = 0.00125; %N

mdot = thrust/(Isp*g0); %kg/s


%Low Thrust Maneuver
theta0 = 0;

rdot0 = 0;

thetadot0 = sqrt(mu/r0)/r0;

x0 = [r0; theta0; rdot0; thetadot0];

tol = 10^-8;

opts = odeset('RelTol', tol,'MaxStep', 10);

[t,x] = ode45(@(t,x) rocketDynamics(t,x,mu,thrust, m0, mdot), [0,500000000],x0);

y = [t,x];

n = 1;

while y(n,2) < r1
    n = n+1;
end

TOF = t(n);

%{
x00 = [x(n, 1), x(n, 2), x(n, 3), x(n, 4)];

m00 = m0 - mdot*t(n);

[tPhase2,xPhase2] = ode45(@(t,x) rocketDynamics(t,x,mu,0, m00, 0), [0,500000000],x00, opts);

yPhase2 = [tPhase2,xPhase2];

n2 = 1;

while abs(xPhase2(1, 1) - yPhase2(n2,3)) < pi()
    n2 = n22+1;
end
%}


%Plotting
figure(1);
hold on
grid on
plot(t(1:n), x(1:n,1));
xlabel('Time (s)');
ylabel('Radial Distance (m)');
hold off

figure(2);
hold on
grid on
axis equal
[xCoord, yCoord] = pol2cart(mod(x(1:n,2), 2*pi), x(1:n,1));
plot(xCoord, yCoord);

%[xCoord2, yCoord2] = pol2cart(mod(xPhase2(1:n2,2), 2*pi), xPhase2(1:n2,1));
%plot(xCoord2, yCoord2, 'g');

x01 = 0;
y01 = 0;
t1 = -pi:0.01:pi;
x1 = x01 + r0*cos(t1);
y1 = y01 + r0*sin(t1);
plot (x1,y1, "k");

x2 = x01 + r1*cos(t1);
y2 = y01 + r1*sin(t1);
plot (x2,y2, "r");

e = (r1-r0)/(r1+r0);

a = (r0+r1)/2;
b = sqrt(a^2*(1 - e^2));

t2 = 0:0.01:pi;

x3 = x01 - a + r0 + a*cos(t2);
y3 = y01 + b*sin(t2);
plot (x3,y3, "m");

xlabel('x (m)');
ylabel('y (m)');
hold off

finalT = y(n,1);

timeCompare = finalT/deltaThohm;

finalTHr = finalT/3600;

finalTDay = finalTHr/24;

deltaV = thrust/mdot*(log(m0) - log(abs(mdot*finalT - m0)));

deltaVcompare = deltaV/deltaVhohm;

m1 = m0 - mdot*finalT;

mprop = mdot*finalT;

mpropH = m0*(1-exp(-1*deltaVhohm/(IspH*g0)));

mdryH = m0 - mpropH;


%Low Thrust ODE
function xdot = rocketDynamics(t, x, GM, thrust, m0, mdot)

    r = x(1);

    theta = x(2);

    rdot = x(3);

    thetadot = x(4);
    
    xdot = [rdot; thetadot; -GM/r^2+r*thetadot^2; 1/r*(thrust/(m0 - mdot*t) - 2*rdot*thetadot)];

end